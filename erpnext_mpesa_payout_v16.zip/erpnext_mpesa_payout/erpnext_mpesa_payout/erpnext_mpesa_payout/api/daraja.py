import base64

import frappe
import requests
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import padding

BASES = {"Sandbox": "https://sandbox.safaricom.co.ke", "Production": "https://api.safaricom.co.ke"}


class MpesaError(Exception):
    """Safaricom definitively rejected the request (safe to retry)."""


def get_token(s):
    key = f"mpesa_payout_token:{s.environment}"
    token = frappe.cache().get_value(key)
    if token:
        return token
    r = requests.get(
        f"{BASES[s.environment]}/oauth/v1/generate",
        params={"grant_type": "client_credentials"},
        auth=(s.consumer_key, s.get_password("consumer_secret")),
        timeout=30,
    )
    if r.status_code != 200:
        raise MpesaError(f"Auth failed ({r.status_code}): check consumer key/secret")
    token = r.json()["access_token"]
    frappe.cache().set_value(key, token, expires_in_sec=3000)
    return token


def security_credential(s):
    cert = x509.load_pem_x509_certificate(s.certificate.strip().encode())
    enc = cert.public_key().encrypt(s.get_password("initiator_password").encode(), padding.PKCS1v15())
    return base64.b64encode(enc).decode()


def b2c(s, amount, phone, remarks, occasion=""):
    """Submit a B2C request. Raises MpesaError on definitive rejection;
    any other exception (timeout etc.) means the outcome is unknown."""
    token = get_token(s)  # auth failures are definitive, so safe to retry
    payload = {
        "InitiatorName": s.initiator_name,
        "SecurityCredential": security_credential(s),
        "CommandID": s.command_id or "BusinessPayment",
        "Amount": int(amount),
        "PartyA": s.shortcode,
        "PartyB": phone,
        "Remarks": remarks[:100],
        "QueueTimeOutURL": s.timeout_url,
        "ResultURL": s.result_url,
        "Occasion": occasion[:100],
    }
    r = requests.post(
        f"{BASES[s.environment]}/mpesa/b2c/v1/paymentrequest",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
        timeout=45,
    )
    try:
        data = r.json()
    except ValueError:
        raise RuntimeError(f"Non-JSON response ({r.status_code})")
    if r.status_code >= 400 or str(data.get("ResponseCode")) != "0":
        if r.status_code == 401:
            frappe.cache().delete_value(f"mpesa_payout_token:{s.environment}")
        raise MpesaError(data.get("errorMessage") or data.get("ResponseDescription") or str(data))
    return data
