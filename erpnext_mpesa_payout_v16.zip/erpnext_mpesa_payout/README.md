# ERPNext M-Pesa Payout

A Frappe app for **ERPNext / Frappe v16** (Python 3.14, Node 24) that connects ERPNext to Safaricom **M-Pesa (Daraja B2C)**. When a
**Payment Entry of type *Pay*** that uses a configured *Mode of Payment* is submitted, the app
queues a B2C request that sends the funds to the party's M-Pesa number, then records the
M-Pesa receipt when Safaricom calls back.

## Flow

1. User submits a Payment Entry (Pay) with the configured Mode of Payment (e.g. "M-Pesa").
2. The `on_submit` hook validates it (KES, whole amount, valid phone, under cap) and creates an **Mpesa Payout Log**.
3. A background job calls Daraja B2C.
4. Safaricom posts to the Result URL: the log becomes *Success* (receipt copied into the Payment Entry's Reference No) or *Failed*.

Statuses: `Queued → Submitted → Success | Failed`, plus `Unknown` (timeout / no response).
**For `Unknown`, check the M-Pesa statement before doing anything**, to avoid paying twice.

## Requirements

- Frappe & ERPNext **v16** (`version-16` branch)
- Python **3.14**, Node.js **24**
- Not compatible with v14/v15 (use the earlier release for those)

## Install

```bash
bench get-app https://github.com/<you>/erpnext_mpesa_payout --branch version-16
bench --site yoursite install-app erpnext_mpesa_payout
bench --site yoursite migrate
bench restart
```

## Configure

1. Create a **Mode of Payment** (e.g. `M-Pesa`) linked to your bank/M-Pesa account (currency **KES**).
2. Open **Mpesa Payout Settings**: choose environment, enter Daraja consumer key/secret, shortcode,
   initiator name/password, paste Safaricom's public certificate (PEM) for that environment,
   pick the Mode of Payment, set a max-amount cap, tick **Enabled**, and Save.
3. Copy the generated **Result URL** and **Queue Timeout URL** into your Daraja app. They contain
   a secret token; callbacks without it are rejected. The site must be reachable over public HTTPS
   (use ngrok/cloudflared for local testing).
4. The phone number comes from `M-Pesa Phone Number` on the Payment Entry, otherwise from the party
   (Employee `cell_number`, Supplier/Customer `mobile_no`).

## Safety notes

- One payout per Payment Entry (idempotent); entries with a live payout can't be cancelled.
- Validation problems never block the accounting entry; they create a *Failed* log you can fix and **Retry**.
- Test in **Sandbox** before going live. B2C must be enabled on your shortcode by Safaricom for production.
- Only KES Payment Entries are supported.

## License
MIT
