frappe.ui.form.on("Mpesa Payout Log", {
	refresh(frm) {
		if (frm.doc.status === "Failed") {
			frm.add_custom_button(__("Retry Payout"), () => {
				frappe.confirm(__("Send this payout to M-Pesa again?"), () => {
					frappe.call({
						method: "erpnext_mpesa_payout.erpnext_mpesa_payout.payout.retry",
						args: { log_name: frm.doc.name },
						callback: () => frm.reload_doc(),
					});
				});
			});
		}
		if (frm.doc.status === "Unknown") {
			frm.dashboard.add_comment(
				__("No confirmation received from M-Pesa. Check the M-Pesa portal statement before doing anything."),
				"orange", true);
		}
	},
});
