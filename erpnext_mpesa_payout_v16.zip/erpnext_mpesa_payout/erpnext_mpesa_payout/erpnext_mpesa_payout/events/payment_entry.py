import frappe

from erpnext_mpesa_payout.erpnext_mpesa_payout import payout


def on_submit(doc, method=None):
    s = frappe.get_single("Mpesa Payout Settings")
    if not s.enabled or doc.payment_type != "Pay":
        return
    if doc.mode_of_payment != s.mode_of_payment:
        return
    # idempotency: never create a second payout for the same entry
    if frappe.db.exists("Mpesa Payout Log", {"payment_entry": doc.name, "status": ["!=", "Failed"]}):
        return
    log = payout.create_log(doc, s)
    if log.status == "Queued":
        payout.enqueue(log.name)
    else:
        frappe.msgprint(f"M-Pesa payout not sent: {log.result_desc}", indicator="orange", alert=True)


def before_cancel(doc, method=None):
    if frappe.db.exists(
        "Mpesa Payout Log",
        {"payment_entry": doc.name, "status": ["in", ["Queued", "Submitted", "Success", "Unknown"]]},
    ):
        frappe.throw(
            "An M-Pesa payout exists for this Payment Entry and it cannot be cancelled. "
            "Recover/reverse the funds via M-Pesa first."
        )
