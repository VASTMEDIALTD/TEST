from frappe.custom.doctype.custom_field.custom_field import create_custom_fields


def after_install():
    create_custom_fields(
        {
            "Payment Entry": [
                {
                    "fieldname": "custom_mpesa_phone",
                    "label": "M-Pesa Phone Number",
                    "fieldtype": "Data",
                    "insert_after": "party_name",
                    "depends_on": "eval:doc.payment_type=='Pay'",
                    "description": "Overrides the party's mobile number. Format: 07XXXXXXXX or 2547XXXXXXXX",
                },
                {
                    "fieldname": "custom_mpesa_payout",
                    "label": "M-Pesa Payout",
                    "fieldtype": "Link",
                    "options": "Mpesa Payout Log",
                    "insert_after": "custom_mpesa_phone",
                    "read_only": 1,
                    "no_copy": 1,
                    "depends_on": "eval:doc.custom_mpesa_payout",
                },
            ]
        }
    )
