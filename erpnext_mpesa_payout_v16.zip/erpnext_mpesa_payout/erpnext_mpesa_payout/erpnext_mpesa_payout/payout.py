import re

import frappe

from erpnext_mpesa_payout.erpnext_mpesa_payout.api import daraja

PHONE_FIELD = {"Employee": "cell_number", "Supplier": "mobile_no", "Customer": "mobile_no"}


def normalize_phone(p):
    p = re.sub(r"\D", "", p or "")
    if len(p) == 10 and p.startswith("0"):
        p = "254" + p[1:]
    elif len(p) == 9 and p[0] in "17":
        p = "254" + p
    return p if re.fullmatch(r"254[17]\d{8}", p) else None


def get_phone(pe):
    raw = pe.get("custom_mpesa_phone")
    if not raw and pe.party_type in PHONE_FIELD:
        raw = frappe.db.get_value(pe.party_type, pe.party, PHONE_FIELD[pe.party_type])
    return normalize_phone(raw)


def create_log(pe, s):
    """Create a log for a Payment Entry. Validation problems produce a Failed log
    (they never block the accounting submit)."""
    phone = get_phone(pe)
    amount = pe.paid_amount
    error = None
    if pe.paid_from_account_currency != "KES":
        error = "Payment account currency must be KES"
    elif not phone:
        error = "No valid Safaricom phone number on the Payment Entry or party"
    elif amount < 1 or amount != int(amount):
        error = "Amount must be a whole number of shillings (>= 1)"
    elif s.max_amount and amount > s.max_amount:
        error = f"Amount exceeds the configured cap of {s.max_amount}"

    log = frappe.get_doc(
        {
            "doctype": "Mpesa Payout Log",
            "payment_entry": pe.name,
            "party_type": pe.party_type,
            "party": pe.party_name or pe.party,
            "amount": amount,
            "phone": phone,
            "status": "Failed" if error else "Queued",
            "result_desc": error,
        }
    ).insert(ignore_permissions=True)
    pe.db_set("custom_mpesa_payout", log.name, update_modified=False)
    return log


def enqueue(log_name):
    frappe.enqueue(
        "erpnext_mpesa_payout.erpnext_mpesa_payout.payout.send",
        queue="short",
        enqueue_after_commit=True,
        log_name=log_name,
    )


def send(log_name):
    log = frappe.get_doc("Mpesa Payout Log", log_name)
    if log.status != "Queued":
        return
    s = frappe.get_single("Mpesa Payout Settings")
    try:
        res = daraja.b2c(s, log.amount, log.phone, f"Payment {log.payment_entry}", occasion=log.payment_entry)
        log.status = "Submitted"
        log.conversation_id = res.get("ConversationID")
        log.originator_conversation_id = res.get("OriginatorConversationID")
        log.result_desc = res.get("ResponseDescription")
    except daraja.MpesaError as e:
        log.status = "Failed"
        log.result_desc = str(e)[:500]
    except Exception as e:  # timeout etc. - money may or may not have moved
        log.status = "Unknown"
        log.result_desc = f"No response from M-Pesa: {e}"[:500]
        frappe.log_error(title="M-Pesa payout unknown state")
    log.save(ignore_permissions=True)
    frappe.db.commit()


@frappe.whitelist()
def retry(log_name):
    frappe.only_for(("Accounts Manager", "System Manager"))
    log = frappe.get_doc("Mpesa Payout Log", log_name)
    if log.status != "Failed":
        frappe.throw("Only Failed payouts can be retried.")
    if frappe.db.get_value("Payment Entry", log.payment_entry, "docstatus") != 1:
        frappe.throw("Payment Entry is not submitted.")
    if frappe.db.exists("Mpesa Payout Log", {"payment_entry": log.payment_entry, "status": ["!=", "Failed"]}):
        frappe.throw("Another payout already exists for this Payment Entry.")
    pe = frappe.get_doc("Payment Entry", log.payment_entry)
    s = frappe.get_single("Mpesa Payout Settings")
    new = create_log(pe, s)  # re-validates phone/amount with current data
    if new.status == "Queued":
        enqueue(new.name)
    return new.name
