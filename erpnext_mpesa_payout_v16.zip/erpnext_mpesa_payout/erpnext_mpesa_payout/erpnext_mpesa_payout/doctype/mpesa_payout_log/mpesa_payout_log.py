from frappe.model.document import Document


class MpesaPayoutLog(Document):
    pass
