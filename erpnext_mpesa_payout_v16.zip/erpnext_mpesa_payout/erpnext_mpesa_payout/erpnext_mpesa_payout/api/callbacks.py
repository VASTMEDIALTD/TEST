import hmac
import json

import frappe

ACK = {"ResultCode": 0, "ResultDesc": "Accepted"}


def _result():
    s = frappe.get_single("Mpesa Payout Settings")
    token = frappe.form_dict.get("token") or ""
    if not s.callback_token or not hmac.compare_digest(token, s.callback_token):
        frappe.throw("Forbidden", frappe.PermissionError)
    try:
        return json.loads(frappe.request.data or b"{}").get("Result") or {}
    except ValueError:
        return {}


def _find_log(r):
    for field, key in (("originator_conversation_id", "OriginatorConversationID"),
                       ("conversation_id", "ConversationID")):
        if r.get(key):
            name = frappe.db.get_value("Mpesa Payout Log", {field: r[key]})
            if name:
                return frappe.get_doc("Mpesa Payout Log", name)


@frappe.whitelist(allow_guest=True, methods=["POST"])
def result():
    r = _result()
    log = _find_log(r)
    if not log or log.status in ("Success", "Failed"):
        return ACK
    params = (r.get("ResultParameters") or {}).get("ResultParameter") or []
    if isinstance(params, dict):
        params = [params]
    params = {p.get("Key"): p.get("Value") for p in params}

    ok = str(r.get("ResultCode")) == "0"
    log.status = "Success" if ok else "Failed"
    log.result_code = str(r.get("ResultCode"))
    log.result_desc = r.get("ResultDesc")
    log.mpesa_receipt = r.get("TransactionID") or params.get("TransactionReceipt")
    log.raw_result = json.dumps(r, indent=1)
    log.save(ignore_permissions=True)

    pe = log.payment_entry
    if ok and log.mpesa_receipt and not frappe.db.get_value("Payment Entry", pe, "reference_no"):
        frappe.db.set_value("Payment Entry", pe,
                            {"reference_no": log.mpesa_receipt, "reference_date": frappe.utils.today()},
                            update_modified=False)
    frappe.get_doc({
        "doctype": "Comment", "comment_type": "Info",
        "reference_doctype": "Payment Entry", "reference_name": pe,
        "content": f"M-Pesa payout {log.status}: {log.mpesa_receipt or log.result_desc} ({log.name})",
    }).insert(ignore_permissions=True)
    return ACK


@frappe.whitelist(allow_guest=True, methods=["POST"])
def timeout():
    r = _result()
    log = _find_log(r)
    if log and log.status == "Submitted":
        log.status = "Unknown"
        log.result_desc = "M-Pesa queue timeout - verify on the M-Pesa portal before retrying."
        log.save(ignore_permissions=True)
    return ACK
