app_name = "erpnext_mpesa_payout"
app_title = "ERPNext Mpesa Payout"
app_publisher = "Your Name"
app_description = "Automatic M-Pesa B2C payouts from ERPNext Payment Entries"
app_email = "you@example.com"
app_license = "MIT"
required_apps = ["erpnext"]

after_install = "erpnext_mpesa_payout.install.after_install"

doc_events = {
    "Payment Entry": {
        "on_submit": "erpnext_mpesa_payout.erpnext_mpesa_payout.events.payment_entry.on_submit",
        "before_cancel": "erpnext_mpesa_payout.erpnext_mpesa_payout.events.payment_entry.before_cancel",
    }
}
