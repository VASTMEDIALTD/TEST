import frappe
from frappe.model.document import Document
from frappe.utils import get_url

CB = "erpnext_mpesa_payout.erpnext_mpesa_payout.api.callbacks"


class MpesaPayoutSettings(Document):
    def validate(self):
        if not self.callback_token:
            self.callback_token = frappe.generate_hash(length=32)
        base = get_url()
        self.result_url = f"{base}/api/method/{CB}.result?token={self.callback_token}"
        self.timeout_url = f"{base}/api/method/{CB}.timeout?token={self.callback_token}"
        if self.enabled and self.environment == "Production" and not base.startswith("https://"):
            frappe.throw("Production requires the site to be served over public HTTPS.")
